#Name: Ridwanur Rahman
#ID: 260828139

import doctest
import datetime
import matplotlib.pyplot as plt

############################## HELPER FUNCTION ########################################

def to_datetime(date):

    for char in date:
        if char == "-":
            date = date.replace(char, ", ")

    date_list = date.split(", ")

    for i, num in enumerate(date_list):
        date_list[i] = int(date_list[i])

    year = date_list[0]
    month = date_list[1]
    day = date_list[2]

    date = datetime.date(year, month, day)

    return date

############################## HELPER FUNCTION ########################################

def date_diff(first_date, second_date):
    """(str, str) -> int
    Takes as input two strings representing dates in ISO format and returns how many
    days apart the two dates are, as an integer.
    """

    first_date = to_datetime(first_date)
    second_date = to_datetime(second_date)

    if first_date < second_date:
        diff = abs(first_date - second_date)
        return diff.days
    else:
        diff = -(first_date - second_date)
        return diff.days

def get_age(first_date, second_date):
    """(str, str) -> int
    Takes as input two strings representing dates in ISO format and returns how many
    complete years apart the two dates are, as an integer.
    """

    first_datetime = to_datetime(first_date)
    second_datetime = to_datetime(second_date)
    complete_year = 365.2425

    year_diff = (first_datetime.year - second_datetime.year) * complete_year

    if (date_diff(first_date, second_date)) > complete_year:

        if first_datetime.year < second_datetime.year:
            difference = abs(year_diff//complete_year)
            return int(difference)
        else:
            difference = -(year_diff//complete_year)
            return int(difference)

    else:

        return 0

def stage_three(input_filename, output_filename):
    """(str, str) -> dict
    """

    in_file = open(input_filename, 'r+')
    out_file = open(output_filename, 'w+')

    out_lines = []
    patient_status = {}

    line = in_file.readline()
    line_content = line.split("\t")
    index_date = line_content[2]

    while (line != ""):

        line_content = line.split("\t")
        out_lines.append(line_content)
        line = in_file.readline()

    for row in out_lines:

        entry_date = row[2]
        birth_date = row[3]
        relative_date = date_diff(index_date, entry_date)
        age = get_age(birth_date, index_date)
        row[2] = relative_date
        row[3] = age
        patient_status[row[2]] = {}

        if row[6][0].lower() == 'i':
            row[6] = 'I'
        elif row[6][0].lower() == 'r':
            row[6] = 'R'
        elif row[6][0].lower() == 'd' or row[6][0].lower() == 'm':
            row[6] = 'D'

    temp_list = []

    for row in out_lines:

        if row[2] in temp_list:
            continue
        else:
            temp_list.append(row[2])

    for pandemic in temp_list:

        patient_status_temp = {'I': 0, 'D': 0, 'R': 0}

        for row in out_lines:

            if row[2] == pandemic:
                for key in patient_status_temp:

                    if key == row[6]:
                        patient_status_temp[key] += 1

        patient_status[pandemic] = patient_status_temp

    in_file.close()

    out_lines_final = []
    for line in out_lines:
        for data in line:
            out_lines_final.append(data)

    for line in out_lines_final:
        out_file.write(str(line))
        if type(line) == str and "\n" in line:
            continue
        else:
            out_file.write("\t")

    out_file.close()

    return patient_status

def plt_time_series(d):
    """(dict) -> list
    """

    temp_list = list(d.values())
    status_list = []

    for dict in temp_list:

        status_list.append(list(dict.values()))

    plt.plot(status_list)

    plt.title("Time series of early pandemic, by Ridwanur Rahman", fontsize = 16)
    plt.xlabel("Days into Pandemic")
    plt.ylabel("Number of People")
    plt.legend(['Infected', 'Recovered', 'Dead'])
    plt.show()
    return status_list


if __name__ == '__main__':
    doctest.testmod()
    #print(to_datetime('2019-10-31'))
    d = stage_three("stage_two.tsv", "stage_three.tsv")
    plt_time_series(d)