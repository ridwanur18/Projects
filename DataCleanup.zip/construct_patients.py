

#Name: Ridwanur Rahman
#ID: 260828139

import doctest
import datetime
import numpy as np
import matplotlib.pyplot as plt

class Patient:
    """Represents a patient.

    Attributes: patient number (int), day diagnosed (int), age (int), gender (str), postal code (str), status (str)
                temp (list), symptomatic (int)
    """

    def __init__(self, patient_num, diagnosis_day, a, s_g, postal_code, status, temperature, days_symptomatic):

        self.num = patient_num
        self.day_diagnosed = diagnosis_day
        self.age = a

        if s_g[0].lower() == 'h' or s_g[0].lower() == 'm':
            self.sex_gender = 'M'

        elif s_g[0].lower() == 'f' or s_g[0].lower() == 'w':
            self.sex_gender = 'F'

        else:
            self.sex_gender = 'X'

        if postal_code[0] == 'H' and postal_code[1].isdigit() and postal_code[2].isalpha():
            self.postal = postal_code[:3]

        else:
            self.postal = '000'

        self.state = status

        if str(temperature)[0].isdigit():

            for char in str(temperature):

                if char == ',':

                    temperature = temperature.replace(char, '.')
                if char == 'C' or char == 'F':

                    temperature = temperature.replace(char, '')
                if char == '°':

                    temperature = temperature.replace(char, '')

                # if char == '-' and (type(temperature[temperature.find(char)+1])==int):
                #     print(char)
                #     temperature = temperature.replace(char,'')
                #     temperature = temperature[0:temperature.find(char)+1] + temperature[temperature.find(char)+2:len(temperature)-1]

        else:

            temperature = 0

        print(temperature)
        temperature = float(temperature)

        if temperature > 45.0:
            temperature = round(((((temperature-32)*(5))/9)), 2)

        self.temps = str(temperature)

        self.days_symptomatic = days_symptomatic


    def __str__(self):

        temp = [str(self.num), str(self.age), self.sex_gender, self.postal, str(self.day_diagnosed), self.state, str(self.days_symptomatic), self.temps + '\n']

        for i, content in enumerate(temp):

            if '\n' in content:
                temp[i] = temp[i].replace('\n', '')
                break

            elif '\t' in content:
                continue

        final = '\t'.join(temp)

        return final


    def update(self, new_p):

        if (self.num == new_p.num and self.sex_gender == new_p.sex_gender and self.postal == new_p.postal):
            self.days_symptomatic = new_p.days_symptomatic
            self.state = new_p.state
            self.temps += '; ' + str(new_p.temps)

        else:
            raise AssertionError("Num/sex gender/postal are not the same.")


def stage_four(input_filename, output_filename):

    in_file = open(input_filename, 'r+')
    out_file = open(output_filename, 'w+')

    patient_info = {}
    info_list = []
    info_list2 = []

    line = in_file.readline()

    while (line != ''):

        info = line.split('\t')
        p = Patient(info[1], info[2], info[3], info[4], info[5], info[6], info[7], info[8])
        info_list.append(p)
        info_list2.append(p)

        line = in_file.readline()


    for i, p in enumerate(info_list):

        if '0' in p.temps[0]:
            continue

        else:

            for j, new_p in enumerate(info_list2):

                if i == j:
                    continue

                else:
                    if p.num == new_p.num and p.sex_gender == new_p.sex_gender and p.postal == new_p.postal:
                        p.update(new_p)

        patient_info[p.num] = str(p)

    in_file.close()

    for key in patient_info:

        out_file.write(str(patient_info[key]))

    out_file.close()

    return patient_info


def fatality_by_age(d):

    x_coord = []
    y_coord = []
    death = 0
    recovery = 0

    for key in d:

        info = d[key].split('\t')
        x_coord.append(info[1])

    for i, num in enumerate(x_coord):

        x_coord[i] = int(5 * round(int(num)/5))

    for age in x_coord:

        for key in d:

            info = d[key].split('\t')

            for num in info:

                info[1] = int(5 * round(int(info[1]) / 5))

            if age == info[1]:

                if info[5] == 'D':
                    death += 1

                elif info[5] == 'R':
                    recovery += 1

        if death == 0 and recovery == 0:

            probability = 1
            y_coord.append(probability)

        else:

            probability = death/(recovery + death)
            y_coord.append(probability)

    plt.plot(x_coord, y_coord)

    plt.xlabel('Age')
    plt.ylabel('Deaths / (Deaths+Recoveries)')
    plt.ylim((0, 1.2))
    plt.title('Probability of death vs age, by Ridwanur Rahman')

    return y_coord


if __name__ == '__main__':
    p = stage_four('stage_three.tsv', 'stage_four.tsv')
    print(fatality_by_age(p))